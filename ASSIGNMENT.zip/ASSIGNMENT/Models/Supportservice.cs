﻿namespace ASSIGNMENT.Models
{
    public class Supportservice
    {
        public string LectureName { get; set; }
        public string Email { get; set; }
        public string LectureId { get; set; }
       
    }
}
